"""
CustomTkinter XY scrollable frame
Author: Akash Bora (Akascape)
License: MIT
Homepage: https://github.com/Akascape/CTkXYFrame
"""

__version__ = '0.3'

from .ctk_xyframe import CTkXYFrame
